import React from 'react';
import ReactDOM from 'react-dom';
import HelloWorld from './HelloWorld';
import Tick from './Tick';

ReactDOM.render(
    <p><HelloWorld /> <Tick /></p>,
    document.getElementById('root')
);